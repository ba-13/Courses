# data

To extract `.tar.gz` files, use `gunzip --filename--` followed by `tar -xf --filename--`.

Contains the following from [LibriSpeech Dataset](https://www.openslr.org/12):

- Development set of LibriSpeech dataset [337M]
- Test set of LibriSpeech dataset [346M]
- Train set of LibriSpeech dataset [6.3G]
